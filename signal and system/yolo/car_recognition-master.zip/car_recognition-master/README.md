# car_recognition 车辆识别
## car_dection
使用训练完成的YOLO模型进行车辆检测
## 拓展
日后增加其他车辆识别相关实现如（车型，牌照。。。）
